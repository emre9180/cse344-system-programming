void gtuStudentGrades(const char *file);
