void sortAll(const char *filename);
