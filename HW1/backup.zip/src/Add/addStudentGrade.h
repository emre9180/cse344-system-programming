void addStudentGrade(const char *filename, const char *name, const char *surname, const char *grade);
